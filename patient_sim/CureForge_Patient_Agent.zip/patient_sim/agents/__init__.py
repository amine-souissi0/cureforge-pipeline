"""Patient simulation agents."""
